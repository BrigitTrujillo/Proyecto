package com.trujillo.brigit.login;

public class User {
    private String user, pwd, nombres;

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        this.pwd = pwd;
    }

    public String getNames() {
        return nombres;
    }

    public void setNames(String names) {
        this.nombres = names;
    }
}
